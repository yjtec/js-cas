# @umi-material/@yjtec/cas

yjtec cas

## Usage

```sh
umi block https://github.com/https://github.com/yjtec/js-cas/tree/master/@yjtec/cas
```

## LICENSE

MIT
