export const cas = {
  type:'1member'
}