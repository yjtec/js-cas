import {Authorized} from 'yjtec-cas';
