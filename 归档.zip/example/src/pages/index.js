import Link from 'umi/link';
export default function() {
  return (
    <div>
      <h1>Page index</h1>
      <Link to="/wxlogin">微信登陆</Link>
    </div>
  );
}
