import React from 'react';
import Cas from 'yjtec-cas';
class Welcome extends React.Component{

  render(){
    return(
      <div>123</div>
    )
  }
}
export default Welcome;